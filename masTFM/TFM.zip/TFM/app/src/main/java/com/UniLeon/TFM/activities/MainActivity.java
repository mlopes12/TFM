package com.UniLeon.TFM.activities;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.UniLeon.TFM.Asynctask.GetAuthorizations;
import com.UniLeon.TFM.Objects.Autorizacion;
import com.UniLeon.TFM.R;
import com.UniLeon.TFM.Utils.ACTION;
import com.UniLeon.TFM.Utils.RegistrosPrograma;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity{

    Context ctx;
    RegistrosPrograma registroPrograma;
    public String auths;


    static ListView listView;
    ImageView enter;
    static ListViewAdapter adapter;
    static ArrayList<Integer> id_auths;
    static ArrayList<String> items;
    static ArrayList<String> plazas;
    static ArrayList<String> emails;
    static Context context;


    private IntentFilter filtro, filtro1, filtro2, filtro3;

    //SINCRO
    ReceptorBroadcast receptorBroadcast;

    //Temporizador
    Timer myTimer;
    boolean _sincronizando=false;
    //Periodo de sincronización: 3min.
    int _tiempoSincronizacion=(1000*60);




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        ctx = this;
        registroPrograma = new RegistrosPrograma(ctx);

        if(registroPrograma.getIdUsuario() == -1){
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }

        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        _tiempoSincronizacion = (100)* registroPrograma.getPeriodoSincronizacion();




        myTimer = new Timer();

        myTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                TimerMethod();
            }

        }, 0, _tiempoSincronizacion);

        //Ponemos a la escucha los filtros: Se ponen en onCreate ya que deben funcionar aunque no está activa
        filtro = new IntentFilter(ACTION.SINCRO_CONTINUA);
        filtro.addCategory(Intent.CATEGORY_DEFAULT);

        filtro1 = new IntentFilter(ACTION.SINCRONIZACION_FALLIDA);
        filtro1.addCategory(Intent.CATEGORY_DEFAULT);

        filtro2 = new IntentFilter(ACTION.FALLO_INTERNET);
        filtro2.addCategory(Intent.CATEGORY_DEFAULT);

        filtro3 = new IntentFilter(ACTION.SINCRO_FINALIZADA);
        filtro3.addCategory(Intent.CATEGORY_DEFAULT);

        receptorBroadcast = new ReceptorBroadcast();

        registerReceiver(receptorBroadcast, filtro);
        registerReceiver(receptorBroadcast, filtro1);
        registerReceiver(receptorBroadcast, filtro2);
        registerReceiver(receptorBroadcast, filtro3);



        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.list);
        enter = findViewById(R.id.add);
        context = getApplicationContext();

        // add hardcoded items to grocery list
        items = new ArrayList<>();
        id_auths = new ArrayList<>();
        plazas = new ArrayList<>();
        emails = new ArrayList<>();

        listView.setLongClickable(true);
        adapter = new ListViewAdapter(this, items);
        listView.setAdapter(adapter);

        // Display the item name when the item's row is clicked
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //aqui nos llevará ala  otra pantalla
                registroPrograma.setIdAAutorizar(id_auths.get(position));
                registroPrograma.setPlazaAAutorizar(plazas.get(position));
                registroPrograma.setEmail(emails.get(position));
                Intent intent = new Intent(MainActivity.this, CodigoActivity.class);
                startActivity(intent);
                finish();
            }
        });
        //loadContent();


    }

    /*public void loadContent() {
        File path = getApplicationContext().getFilesDir();
        File readFrom = new File(path, "list.txt");
        byte[] content = new byte[(int) readFrom.length()];

        FileInputStream stream = null;
        try {
            stream = new FileInputStream(readFrom);
            stream.read(content);

            String s = new String(content);
            // [Apple, Banana, Kiwi, Strawberry]
            s = s.substring(1, s.length() - 1);
            String split[] = s.split(", ");

            // There may be no items in the grocery list.
            if (split.length == 1 && split[0].isEmpty()) {
                items = new ArrayList<>();
            }else {
                items = new ArrayList<>(Arrays.asList(split));
            }

            adapter = new ListViewAdapter(this, items);
            listView.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/



    @Override
    protected void onStop() {
        super.onStop();
    }



    @Override
    protected void onRestart() {
        super.onRestart();

    }

    @Override
    protected void onDestroy() {
        /*File path = getApplicationContext().getFilesDir();
        try {
            FileOutputStream writer = new FileOutputStream(new File(path, "list.txt"));
            writer.write(items.toString().getBytes());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }*/
        super.onDestroy();
        try {
            this.unregisterReceiver(receptorBroadcast);
        }catch (Exception e){}
        if(myTimer!=null)
            myTimer.cancel();
    }

    // function to remove an item given its index in the grocery list.
    public static void removeItem(int i) {
        //makeToast("Removed: " + items.get(i));
        int posicion = id_auths.indexOf(i);
        id_auths.remove(posicion);
        items.remove(posicion);
        plazas.remove(posicion);
        emails.remove(posicion);
        listView.setAdapter(adapter);
    }

    // function to add an item given its name.
    public static void addItem(String item, int id_auth, String plaza, String email) {
        id_auths.add(id_auth);
        items.add(item);
        plazas.add(plaza);
        emails.add(email);
        listView.setAdapter(adapter);
    }

    // function to make a Toast given a string
    static Toast t;

    private static void makeToast(String s) {
        if (t != null) t.cancel();
        t = Toast.makeText(context, s, Toast.LENGTH_SHORT);
        t.show();
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home)
            onBackPressed();
        return true;
    }



    //Receptor
    public class ReceptorBroadcast extends BroadcastReceiver {

        @Override
        public void onReceive(Context arg0, Intent intent){

            if(ACTION.SINCRO_CONTINUA.equals(intent.getAction()) ){

            }
            else{

                if( ACTION.SINCRO_FINALIZADA.equals(intent.getAction()) ){
                    ArrayList<Autorizacion> autorizaciones_existentes = new ArrayList<Autorizacion>();
                    ArrayList<Autorizacion> autorizaciones_nuevas = new ArrayList<Autorizacion>();
                    try {
                        String autorizaciones = registroPrograma.getAutorizaciones();
                        JSONObject jsonChildNode = null;
                        jsonChildNode = new JSONObject( autorizaciones );


                        JSONArray lista_autorizaciones = new JSONArray();
                        lista_autorizaciones = (JSONArray) jsonChildNode.get("autorizacion");

                        for (int i = 0; i < lista_autorizaciones.length(); i++) {
                            JSONObject autorizacion_simple =new JSONObject(  );
                            autorizacion_simple = (JSONObject) lista_autorizaciones.get(i);


                            Autorizacion autorizacion = new Autorizacion(autorizacion_simple.optInt("id"),
                                    autorizacion_simple.optString("plaza"),
                                    autorizacion_simple.optString("fecha"),
                                    autorizacion_simple.optString("email"));
                            autorizaciones_existentes.add(autorizacion);
                        }

                        autorizaciones = auths;
                        jsonChildNode = new JSONObject( autorizaciones );


                        lista_autorizaciones = (JSONArray) jsonChildNode.get("autorizacion");

                        for (int i = 0; i < lista_autorizaciones.length(); i++) {
                            JSONObject autorizacion_simple =new JSONObject(  );
                            autorizacion_simple = (JSONObject) lista_autorizaciones.get(i);


                            Autorizacion autorizacion = new Autorizacion(autorizacion_simple.optInt("id"),
                                    autorizacion_simple.optString("plaza"),
                                    autorizacion_simple.optString("fecha"),
                                    autorizacion_simple.optString("email"));
                            autorizaciones_nuevas.add(autorizacion);
                        }
                        registroPrograma.setAutorizaciones(autorizaciones);

                        ArrayList<Autorizacion> autorizaciones_existentes_ = autorizaciones_existentes;
                        ArrayList<Autorizacion> autorizaciones_nuevas_ = autorizaciones_nuevas;

                        autorizaciones_existentes_.removeAll(autorizaciones_nuevas);
                        autorizaciones_nuevas_.removeAll(autorizaciones_existentes);


                        for (int i = 0; i < autorizaciones_nuevas_.size(); i++) {
                            addItem(autorizaciones_nuevas_.get(i).getPlaza() + " a fecha " + autorizaciones_nuevas_.get(i).getFecha(), autorizaciones_nuevas_.get(i).getId(), autorizaciones_nuevas_.get(i).getPlaza(), autorizaciones_nuevas_.get(i).getEmail());
                        }
                        for (int i = 0; i < autorizaciones_existentes_.size(); i++) {
                            removeItem(autorizaciones_nuevas_.get(i).getId());
                        }




                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
                else if( ACTION.SINCRONIZACION_FALLIDA.equals(intent.getAction()) ){
                    Toast.makeText(getApplicationContext(), "Error de sincronización", Toast.LENGTH_LONG).show();
                }
                else if( ACTION.FALLO_INTERNET.equals(intent.getAction()) ) {
                    Toast.makeText(getApplicationContext(), "Error de conexión a Internet", Toast.LENGTH_LONG).show();
                }

                _sincronizando = false;
            }
        }
    }



    //Timer Sincronizar

    private void TimerMethod()
    {
        this.runOnUiThread(Timer_Tick);
    }

    private Runnable Timer_Tick = new Runnable() {
        public void run() {
            Sincronizar();
        }
    };

    public void Sincronizar(){
        _sincronizando = false;
        if(!_sincronizando){
            _sincronizando = true;

            //receptorBroadcast=new ReceptorBroadcast();

            GetAuthorizations dhr= new GetAuthorizations( ctx);
            dhr.execute("");
        }
    }



}




class ListViewAdapter extends ArrayAdapter<String> {
    ArrayList<String> list;
    Context context;

    // The ListViewAdapter Constructor
    // @param context: the Context from the MainActivity
    // @param items: The list of items in our Grocery List
    public ListViewAdapter(Context context, ArrayList<String> items) {
        super(context, R.layout.list_row, items);
        this.context = context;
        list = items;
    }

    // The method we override to provide our own layout for each View (row) in the ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater mInflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.list_row, null);
            TextView name = convertView.findViewById(R.id.name);

            name.setText(list.get(position));

        }
        return convertView;
    }

}

